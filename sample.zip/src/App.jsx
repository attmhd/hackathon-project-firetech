// src/App.jsx

import Hero from './components/Hero';

function App() {
  return (
    // DIUBAH: Padding di HP 'p-4', di tablet 'sm:p-6', di desktop 'md:p-8'
    <div className="bg-[#F5E8D0] min-h-screen p-4 sm:p-6 md:p-8"> 
      <Hero /> 
    </div>
  );
}

export default App;