// src/components/Hero.jsx

import MascotImage from '../assets/Maskotsatu.png';
import Header from './layout/Header'; 

function Hero() {
  return (
    <section>
      {/* DIUBAH: Padding diatur agar responsif */}
      <div className="bg-[#E6B17E]/67 rounded-[3.5rem] max-w-7xl mx-auto 
                  px-6 sm:px-12 md:px-16 lg:px-20 
                  py-8 sm:py-10 
                  shadow-lg">
        
        <Header /> 

        {/* DIUBAH: Margin atas dikurangi di HP */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mt-8 md:mt-12 lg:mt-16"> 
          
          {/* Kolom Kiri: Teks & CTA */}
          <div className="text-[#473322]">
            {/* DIUBAH: Ukuran font judul dibuat responsif */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold !leading-tight">
              MinangLanguage
            </h1>
            {/* DIUBAH: Ukuran font subjudul dibuat responsif */}
            <p className="mt-4 text-lg sm:text-xl md:text-2xl font-medium">
              adalah platform terbuka untuk mempelajari, 
              mendokumentasikan, dan melestarikan ragam bahasa 
              daerah di Sumatera Barat.
            </p>
            <p className="mt-6 text-base opacity-80">
              Satu platform untuk menjaga dan belajar bahasa daerah Minangkabau dari berbagai nagari
            </p>
            
            <button className="mt-10 h-14 px-8 bg-[#FF8D28] text-white rounded-full font-bold text-base hover:brightness-110 transition shadow-lg">
              Eksplor Bahasa
            </button>
          </div>

          {/* Kolom Kanan: Gambar Maskot */}
          {/* DIUBAH: 'lg:translate-x-24' sudah benar, tapi kita pastikan kolomnya tidak berantakan */}
          <div className="flex items-center justify-center lg:justify-end relative lg:translate-x-24"> 
            <img 
              src={MascotImage} 
              alt="Maskot Kerbau MinangLanguage" 
              className="w-full max-w-md object-contain"
            />
          </div>

        </div>
      </div>
    </section>
  );
}

export default Hero;