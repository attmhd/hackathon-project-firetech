// src/components/layout/Header.jsx

import { useState } from 'react'; // Pastikan useState di-impor
import LogoImage from '../../assets/LOGO.png';

/**
 * Ikon SVG
 */
const SearchIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-zinc-400">
    <circle cx="11" cy="11" r="8"></circle>
    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
  </svg>
);

const MicrophoneIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-zinc-400">
    <path d="M12 1v9"></path>
    <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
    <line x1="12" y1="19" x2="12" y2="23"></line>
    <line x1="8" y1="23" x2="16" y2="23"></line>
  </svg>
);

const PlusIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
);

const MenuIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="3" y1="12" x2="21" y2="12"></line>
    <line x1="3" y1="6" x2="21" y2="6"></line>
    <line x1="3" y1="18" x2="21" y2="18"></line>
  </svg>
);

const XIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>
);
// --- Akhir Ikon ---


function Header() {
  const textColor = "text-[#473322]"; 
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="relative">
      <div>
        
        {/* BARIS 1: Logo, Nav, Tombol */}
        <div className="flex items-center justify-between md:grid md:grid-cols-3 md:gap-8">
          
          {/* Kiri: Logo (Kolom 1) */}
          <div className="flex-shrink-0">
            <img 
              src={LogoImage} 
              alt="MinangLanguage Logo" 
              className="h-10 md:h-16" // Responsif: h-10 di HP, h-16 di Desktop
            />
          </div>

          {/* Tengah: Navigasi (Kolom 2) */}
          <nav className="hidden md:flex gap-8 justify-center">
            <a href="#" className={`text-sm font-medium ${textColor} hover:opacity-75 transition-opacity`}>Home</a>
            <a href="#" className={`text-sm font-medium ${textColor} hover:opacity-75 transition-opacity`}>Kamus</a>
            <a href="#" className={`text-sm font-medium ${textColor} hover:opacity-75 transition-opacity`}>Terjemahan</a>
          </nav>

          {/* Kanan: Tombol Kontribusi (Kolom 3) & Tombol Hamburger */}
          <div className="flex items-center justify-end">
            
            {/* Tombol Kontribusi DESKTOP (Sembunyi di HP) */}
            <button className="hidden md:flex flex-shrink-0 h-12 px-5 items-center gap-2 bg-[#FF8D28] text-white rounded-full font-medium text-sm hover:brightness-110 transition shadow-lg">
              <PlusIcon />
              Kontribusi
            </button>
            
            {/* Tombol Hamburger MOBILE (Sembunyi di Desktop) */}
            <button 
              className={`md:hidden p-2 rounded-md ${textColor}`}
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <XIcon /> : <MenuIcon />}
            </button>
          </div>
        </div>

        {/* BARIS 2: Form Pencarian */}
        <div className="flex justify-center mt-4 md:mt-6"> 
          <div className="relative w-full max-w-lg sm:max-w-xl">
            <input
              type="text"
              placeholder="Cari kata dalam bahasa Indonesia..." // Placeholder yang benar
              className=" text-black w-full h-12 pl-12 pr-12 rounded-full border border-zinc-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#E6B17E] text-sm"
            />
            {/* Ikon Search */}
            <div className="absolute left-4 top-1/2 -translate-y-1/2">
              <SearchIcon />
            </div>
            {/* Ikon Mikrofon */}
            <div className="absolute right-4 top-1/2 -translate-y-1/2">
              <MicrophoneIcon />
            </div>
          </div>
        </div>
      </div>

      {/* Dropdown Menu untuk MOBILE */}
      {isMenuOpen && (
        <div 
          className="md:hidden mt-4 bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg p-6"
        >
          <nav className="flex flex-col gap-4 font-bold">
            <a href="#" className={`text-lg font-medium ${textColor} hover:opacity-75`}>Home</a>
            <a href="#" className={`text-lg font-medium ${textColor} hover:opacity-75`}>Kamus</a>
            <a href="#" className={`text-lg font-medium ${textColor} hover:opacity-75`}>Terjemahan</a>
          </nav>
          
          {/* Tombol Kontribusi MOBILE */}
          <a href='/kontributor'>
          <button className="mt-6 w-full flex-shrink-0 h-12 px-5 flex items-center justify-center gap-2 bg-[#FF8D28] text-white rounded-full font-medium text-sm hover:brightness-110 transition shadow-lg">
            <PlusIcon />
            Kontribusi
          </button></a>
        </div>
      )}
    </header>
  );
}

export default Header;